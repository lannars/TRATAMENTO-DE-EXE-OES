import React, {useState} from "react";
import { View, TextInput, Button, StyleSheet } from "react-native";
import Toast from "react-native-toast-message";

export default function TratamentoExecoes(){
    const[valor, setValor] = useState('');
    const divisao = () =>{
        try{
            const numero = parseFloat(valor);
            if(isNaN(numero)){
                throw new Error("Insira um numero");
            }
            if(numero == 0){
                throw new Error("Insira um numero");
            }
            const resultado = 100 / numero;
            Toast.show({
                type: 'sucess',
                text1: 'Resultado',
                texto2:`100 dividido por ${numero}`
            })
        }catch(erro){
            Toast.show({
                type: 'error',
                texto1: 'exeção disparada',
                texto2: error.message,
        })
    }
    };
    return(
        <View style={style.container}>
            <TextInput
            style={style.input}
            placeholder='Digite um número'
            keyboardType='numeric'
            value={valor}
            onChangeText={setValor}>
        <Button title="Divir" onPress={divisao}/>
        <Toast/>
        </TextInput>
        </View>
    );
    const styles = StyleSheet.create({
        container: {
            felix: 1,
            justifyContent:'center',
            alignItems:'center',
            padding: 20       
        },
        input:{
            borderWidth:1,
            borderColor:'#ccc',
            padding: 10,
            marginBottom:20,
            width: '80%'
        }
    })
}